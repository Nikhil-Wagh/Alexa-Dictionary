## Alexa Dictionary

#### Features
1. Definition
2. Synonyms
3. Antonyms
4. Examples
5. Spelling
6. Pronounciation
7. Etymologies
8. Domains and Regions
9. Multiple Languages
