n = 2
s = "definition " + ("are" if n > 1 else "is")  
print (s)